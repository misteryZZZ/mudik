import ManifestView from '../libs/views/manifest'

export default function Home() {
  return (
    <ManifestView />
  )
}
