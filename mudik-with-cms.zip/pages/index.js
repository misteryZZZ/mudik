import DashboardView from '../libs/views/dashboard'

export default function Home() {
  return (
    <DashboardView />
  )
}
