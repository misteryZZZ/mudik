import LoginView from '../libs/views/login'

export default function Home() {
  return (
    <LoginView />
  )
}
