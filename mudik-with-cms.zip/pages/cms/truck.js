import TruckView from '../../libs_cms/views/truck'

export default function Truck() {
  return (
    <TruckView />
  )
}
