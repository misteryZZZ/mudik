import LoginView from '../../libs_cms/views/login'

export default function Home() {
  return (
    <LoginView />
  )
}
