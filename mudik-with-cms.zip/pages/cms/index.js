import TripView from '../../libs_cms/views/trip'

export default function Trip() {
  return (
    <TripView />
  )
}
