import CityView from '../../libs_cms/views/city'

export default function City() {
  return (
    <CityView />
  )
}
