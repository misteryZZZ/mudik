import BusView from '../../libs_cms/views/bus'

export default function Bus() {
  return (
    <BusView />
  )
}
