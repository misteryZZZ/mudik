import LiveMapView from '../libs/views/liveMap'

export default function Home() {
  return (
    <LiveMapView />
  )
}
