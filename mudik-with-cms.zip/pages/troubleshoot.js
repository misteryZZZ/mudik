import TroubleshootView from '../libs/views/troubleshoot'

export default function Home() {
  return (
    <TroubleshootView />
  )
}
