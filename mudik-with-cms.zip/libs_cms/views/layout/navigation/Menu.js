import React from 'react';
import Link from 'next/link';

export const Wrapper = ({ children }) => (
  <ul className="menu">{children}</ul>
);

export const Trip = ({ active }) => (
  <li className={active ? 'active' : null}>
    <Link href="/cms">
      <div className="flex items-center relative px-6 py-3 hover:bg-white/10 cursor-pointer">
        <p className="ml-4">Trip</p>
      </div>
    </Link>
  </li>
);

export const Bus = ({ active }) => (
  <li className={active ? 'active' : null}>
    <Link href="/cms/bus">
      <div className="flex items-center relative px-6 py-3 hover:bg-white/10 cursor-pointer">
        <p className="ml-4">Bus</p>
      </div>
    </Link>
  </li>
);

export const Truck = ({ active }) => (
  <li className={active ? 'active' : null}>
    <Link href="/cms/truck">
      <div className="flex items-center relative px-6 py-3 hover:bg-white/10 cursor-pointer">
        <p className="ml-4">Truck</p>
      </div>
    </Link>
  </li>
);

export const City = ({ active }) => (
  <li className={active ? 'active' : null}>
    <Link href="/cms/city">
      <div className="flex items-center relative px-6 py-3 hover:bg-white/10 cursor-pointer">
        <p className="ml-4">City</p>
      </div>
    </Link>
  </li>
);
