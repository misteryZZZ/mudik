import React from 'react';

const Brand = () => {
  return (
    <div className="p-6 mb-8">
      <h1 className="text-3xl">MudikGratis<br/>DKI Jakarta<br/>2022</h1>
    </div>
  );
}

export default Brand;